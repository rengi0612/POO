using System;

namespace Pruebas.Models
{
    public class mensaje
    {
        public String Mess { get; set; }
        public long id {get; set;}
    }
}
